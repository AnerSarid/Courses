public class HelloGoodbye {
    public static void main(String args[]) {
        System.out.println("Hello " + args[0] + " And " + args[1] + ".");
        System.out.println("Goodbye " + args[1] + " And " + args[0] + ".");
    }
}
